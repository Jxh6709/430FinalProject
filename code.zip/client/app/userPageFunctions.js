const updateUser = (user) => {
    console.log(user);
};
