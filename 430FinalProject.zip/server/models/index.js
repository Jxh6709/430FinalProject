module.exports.Account = require('./Account.js');
module.exports.Faculty = require('./Faculty');
module.exports.Courses = require('./Courses');
