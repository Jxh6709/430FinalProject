module.exports.Account = require('./Account');
module.exports.MainApp = require('./MainApp');
module.exports.UserPage = require('./usersPage');
module.exports.Faculty = require('./Faculty');
module.exports.Courses = require('./Courses');
module.exports.SendPage = require('./SendPage');
